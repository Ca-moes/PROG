#pragma once

#include <string>

const std::string AGENCY_FILE_NAME="agency.txt";

