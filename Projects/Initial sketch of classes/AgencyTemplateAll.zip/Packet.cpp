#include "Packet.h"

Packet::Packet(vector<string> sites, Date inicio, Date fim, double precoPessoa, unsigned maxPessoas){

  // REQUIRES IMPLEMENTATION
}

  // metodos GET

unsigned Packet::getId() const{

  // REQUIRES IMPLEMENTATION
}

vector<string> Packet::getSites() const{

  // REQUIRES IMPLEMENTATION
}

Date Packet::getBeginDate() const{

  // REQUIRES IMPLEMENTATION
}

Date Packet::getEndDate() const{

  // REQUIRES IMPLEMENTATION
}

double Packet::getPricePerPerson() const{

  // REQUIRES IMPLEMENTATION
}

unsigned Packet::getMaxPersons() const{

  // REQUIRES IMPLEMENTATION
}

  // metodos SET

void Packet::setId(unsigned id){

  // REQUIRES IMPLEMENTATION
}

void Packet::setSites(vector<string> sites){

  // REQUIRES IMPLEMENTATION
}

void Packet::setBeginDate(Date begin){

  // REQUIRES IMPLEMENTATION
}

void Packet::setEndDate(Date end){

  // REQUIRES IMPLEMENTATION
}

void Packet::setPricePerPerson(double pricePerPerson){

  // REQUIRES IMPLEMENTATION
}

void Packet::setMaxPersons(unsigned maxPersons){

  // REQUIRES IMPLEMENTATION
}


/*********************************
 * Show Packet information
 ********************************/  

// shows a packet content 
ostream& operator<<(ostream& out, const Packet & packet){

  // REQUIRES IMPLEMENTATION
}
