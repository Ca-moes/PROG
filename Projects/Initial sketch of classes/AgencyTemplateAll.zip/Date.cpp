#include "Date.h"

Date::Date(){
}

Date::Date(string date){
  
  // REQUIRES IMPLEMENTATION

}


Date::Date(unsigned short day, unsigned short month, unsigned year){

  // REQUIRES IMPLEMENTATION
}

/*********************************
 * GET Methods
 ********************************/
unsigned short Date::getDay() const{

  // REQUIRES IMPLEMENTATION

}

  
unsigned short Date::getMonth() const{

  // REQUIRES IMPLEMENTATION

}
    
unsigned Date::getYear() const{

  // REQUIRES IMPLEMENTATION

}

/*********************************
 * SET Methods
 ********************************/

void Date::setDay(unsigned short day){
  
  // REQUIRES IMPLEMENTATION

}
void Date::setMonth(unsigned short month){
  
  // REQUIRES IMPLEMENTATION

}

void Date::setYear(unsigned year){

  // REQUIRES IMPLEMENTATION

}


/*********************************
 * Show Date
 ********************************/  

// disply a Date in a nice format
ostream& operator<<(ostream& out, const Date & date){

  // REQUIRES IMPLEMENTATION

}
