#include "Client.h"

Client::Client(string name, unsigned VATnumber, unsigned short familySize, Address address){
  
  // REQUIRES IMPLEMENTATION 
}

Client::Client(string name, unsigned VATnumber, unsigned short familySize, Address address, vector<Packet> & packets, unsigned totalPurchased){
  
  // REQUIRES IMPLEMENTATION 
}

  // GET methods

string Client::getName() const{
  
  // REQUIRES IMPLEMENTATION 
}
  
unsigned Client::getVATnumber() const{
  
  // REQUIRES IMPLEMENTATION 
}

unsigned short Client::getFamilySize() const{
  
  // REQUIRES IMPLEMENTATION 
}

Address Client::getAddress() const{
  
  // REQUIRES IMPLEMENTATION 
}

vector<Packet> Client::getPacketList() const{
  
  // REQUIRES IMPLEMENTATION 
}

unsigned Client::getTotalPurchased() const{
  
  // REQUIRES IMPLEMENTATION 
}
  
  // metodos SET
	  
void Client::setName(string nome){
  
  // REQUIRES IMPLEMENTATION 
}

void Client::setVATnumber(unsigned VATnumber){
  
  // REQUIRES IMPLEMENTATION 
}

void Client::setFamilySize(unsigned short familySize){
  
  // REQUIRES IMPLEMENTATION 
}
void Client::setAddress(Address address){
  
  // REQUIRES IMPLEMENTATION 
}
void Client::setPacketList(vector<Packet> & packets){
  
  // REQUIRES IMPLEMENTATION 
}
unsigned Client::setTotalPurchased(unsigned totalPurchased){
  
  // REQUIRES IMPLEMENTATION 
}
  
  // outros metodos

ostream& operator<<(ostream& out, const Client & client){

  // REQUIRES IMPLEMENTATION 

}
